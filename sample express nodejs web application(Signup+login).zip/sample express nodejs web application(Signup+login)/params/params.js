const DATABASECONNECTION = "mongodb+srv://root:root@cluster0.jdf9z.mongodb.net/?retryWrites=true&w=majority"

module.exports = {
    DATABASECONNECTION
}