<Open Visual Studio>
<open Terminal>
<Run command>nodemon app

got to :localhost:3000
